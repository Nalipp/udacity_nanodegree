# Colorizr

Colorizr allows you to change the color of your text in the terminal.

## Installation

Add this line to your application's Gemfile:

```ruby
gem 'colorizr'
```

And then execute:

    $ bundle

Or install it yourself as:

    $ gem install colorizr

## Usage
Simply pass the color you want to a string.

##### example
###
```
puts "John".red

puts "Paul".green

puts "George".blue

puts "Ringo".yellow
```
For a list of sample colors
```
puts String.sample_colors
```
