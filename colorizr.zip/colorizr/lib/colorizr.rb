class String

  def self.colors
    [:red, :green, :yellow, :blue, :pink, :light_blue, :white, :light_grey, :black]
  end

  @@colors = []

  def self.create_colors
      colors.each_with_index do |color, index|
      self.send(:define_method, "#{color}") do
      "\e[#{index + 31}m #{self}\e[0m"
      end
    end
  end

  String.create_colors

  def self.sample_colors
    colors.each_with_index do |color, index|
        puts "This is " + "\e[#{index + 31}m #{color}\e[0m"
    end
  end
end
