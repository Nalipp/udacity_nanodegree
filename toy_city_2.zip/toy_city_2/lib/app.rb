require 'json'
require 'artii'
require 'date'

def setup
	path = File.join(File.dirname(__FILE__), '../data/products.json')
	file = File.read(path)
	$products_hash = JSON.parse(file)
	$report_file = File.new("report.txt", "w+")
end

def ascii(text, options = {}) # Print headings in ascii art
	a = Artii::Base.new
  $report_file.puts a.asciify("#{text}")
	$report_file.puts options[:space]
end

def date
  $report_file.puts "Date : " + Date.today.strftime('%a %d %b %Y').to_s
	$report_file.puts space_break
end

def space_break
  "*"*50
end

def space_title(title, spaces=18)
	"#{title}".ljust(spaces) + ": "
end

def start
  setup
  ascii("Sales Report") # Print "Sales Report" in ascii art
  date
  ascii("Products", space: space_break)
  run_products
  ascii("Brands", space: space_break)
	run_brands
end

################  Products  ##################

def run_products
  $products_hash["items"].each do |toy|
		product_result = calculate_products(toy)
    print_products_report(product_result)
  end
end

def calculate_products(toy)
	@toy_title = toy["title"]
	@full_price = toy["full-price"]
	@total_purchased = toy["purchases"].count.to_s
	@total_sales = toy["purchases"].map { |purchase| purchase["price"] }.reduce(:+)
	@average_price = (total_sales(toy) / toy["purchases"].count).to_s
	@average_discount = '%.02f' %(toy["full-price"].to_f - (total_sales(toy) / toy["purchases"].count)).to_s
end

def print_products_report(product_result)
	$report_file.puts space_title("Item name") + @toy_title
	$report_file.puts space_title("Retail price") + @full_price
	$report_file.puts space_title("Purchases") + @total_purchased
	$report_file.puts space_title("Total sales") + @total_sales.to_s
	$report_file.puts space_title("Average price") + @average_price
	$report_file.puts space_title("Average discount") + @average_discount
	$report_file.puts space_break
end

def total_sales(toy)
  toy["purchases"].map { |purchase| purchase["price"] }.reduce(:+)
end

################  Brands  ##################

def uniq_brands #Returns array of brands
	$products_hash["items"].map { |item| item["brand"] }.uniq
end

def brand_totals #Returns arrays of toy prices for each brand
	brand_totals = []
	uniq_brands.each do |brand|
		total = []
		$products_hash["items"].map do |item|
			total << item["purchases"].map { |purchase| purchase["price"] if item["brand"] == brand }.compact
		end
		brand_totals << total
	end
	brand_totals
end

def brand_stock #Returns an aray toys in stock per brand
	brand_stock = []
	uniq_brands.each do |brand|
		brand_stock << $products_hash["items"].map { |item| item["brand"] == brand ? item["stock"] : 0 }.reduce(:+)
	end
	brand_stock
end

def run_brands
	uniq_brands.each_with_index do |brand, index|
		brand_results = calculate_brands(brand, index)
		print_brands_report(brand_results)
	end
end

def calculate_brands(brand, index)
	@brand_name = brand
  @brand_stock = brand_stock[index]
 	@brand_average_price = (brand_totals[index].flatten.reduce(:+).round(2) / brand_totals[index].flatten.size ).to_s
	@brand_total_sales = brand_totals[index].flatten.reduce(:+).round(2).to_s
end

def print_brands_report(brand_results)
	$report_file.puts space_title("Brand name", 14) + @brand_name
	$report_file.puts space_title("Toys in stock", 14) + @brand_stock.to_s
	$report_file.puts space_title("Average price", 14) + @brand_average_price
	$report_file.puts space_title("Total sales", 14) + @brand_total_sales
	$report_file.puts space_break
end

start
