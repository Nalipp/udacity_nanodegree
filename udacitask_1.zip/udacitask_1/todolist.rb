require 'date'

class TodoList
  attr_reader :items
  attr_accessor :title

  def initialize(list_title)
    @title = list_title
    @items = []
  end

  def create_item(description) # create an item and pass in the description
    item = Item.new(description)
    @items.push(item)
  end

  def delete(index) # delete an item by passing in it's index
    @items.delete_at(index - 1)
  end

  def toggle_complete_status(index) # toggle item's complete status by passing in it's index
    @items[index - 1].toggle_complete
  end

  def urgent(index)
    @items[index - 1].toggle_urgent
  end

  def move_item(current_index, new_index)
    item = @items[current_index - 1]
    @items.delete_at(current_index - 1)
    @items.insert(new_index - 1, item)
  end

  def update_title(list_title) # update the list tile by passing in new title
    @title = list_title
  end

  def list_index
    @items.each.with_index
  end

  def return_all_items
    @items.each_with_index { |item, index| puts "#{index + 1}: " + item.print_item(list_index) }
  end

  def print_list
    puts @title + "               :  " +  date.to_s + "   :"
    puts space_break
    return_all_items
    puts space_break
    puts "\n"
  end

  def space_break
    "*"*50
  end

  def date
  Date.today.strftime('%a %d %b %Y').to_s
  end
end

class Item
  attr_accessor :description, :urgent_status
  attr_reader :completion_status

  def initialize(description)
    @description = description
    @completion_status = false
  end

  def completed?
    @completion_status
  end

  def toggle_complete
    @completion_status = !@completion_status
  end

  def urgent?
    @urgent_status
  end

  def toggle_urgent
    @urgent_status = !@urgent_status
  end

  def print_item(index)
    completion_status = completed? ? "[x]" : "[ ]"
    urgent_status = urgent? ? "[URGENT]" : ""
    "#{completion_status} #{urgent_status} #{description}"
  end
end
