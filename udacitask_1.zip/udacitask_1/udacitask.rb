require_relative 'todolist.rb'

# Creates a new todo list
monday_list = TodoList.new("Mondays list")
# Add four new items
monday_list.create_item "Clean up the neighborhood"
monday_list.create_item "Transer some energy"
monday_list.create_item "Look for stardust"
monday_list.create_item "Become an insurance salesman"
# Print the list
monday_list.print_list
# Delete the first item
monday_list.delete(1)
# Print the list
monday_list.print_list
# Delete the second item
monday_list.delete(2)
# Print the list
monday_list.print_list
# Update the completion status of the first item to complete
monday_list.toggle_complete_status(1)
# Print the list
monday_list.print_list
# Update the title of the list
monday_list.update_title("Things to do")
# Print the list
monday_list.print_list
##Extra: Unmark the 1 item as incomplete
monday_list.toggle_complete_status(1)
##EXTRA: Print list
monday_list.print_list
##EXTRA: Mark the first item as urgent
monday_list.urgent(1)
##EXTRA: Print list
monday_list.print_list
##EXTRA: Create two new items
monday_list.create_item "Count the internet"
monday_list.create_item "Watch TV"
##EXTRA: Print list
monday_list.print_list
##EXTRA: Move the 4rd item to the second position
monday_list.move_item(4, 2)
##EXTRA: Print list
monday_list.print_list

monday_list.toggle_complete_status(3)
monday_list.print_list
